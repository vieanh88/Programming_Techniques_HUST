#include <stdio.h>
//Do Thi Thanh Binh 20215315

//Ham tinh lap phuong cua x voi dau vao la so nguyen x  
int cube(int x) {
    return x*x*x; //Tra ve lap phuong cua x voi gia tri kieu nguyen  
}
//Ham tinh lap phuong cua x voi dau vao la so kieu double  
double cube(double x) {
    return x*x*x; //Tra ve lap phuong cua x voi gia tri kieu double  
}


int main() {
    int n;
    double f;
    scanf("%d %lf", &n, &f);
    
    printf("Int: %d\n", cube(n));
    printf("Double: %.2lf\n", cube(f));
    
    return 0;
}
