#include <iostream>
using namespace std;
//Do Thi Thanh Binh 20215315 
template <typename T>
T arr_sum(T a[], int n, T b[], int m) { //Ham cong cac phan tu cua mang voi kieu du lieu dau vao  
    T sum = 0; //Bien tinh tong 
    for(int i=0; i<n; i++){
        sum += a[i]; //Tong cac phan tu cua a
    }
    for(int i=0; i<m; i++){
        sum += b[i]; //Tong cac phan tu cua a v� b
    }
    return sum;
}

int main() {
    int val;
    cin >> val;
    
    {
        int a[] = {3, 2, 0, val};
        int b[] = {5, 6, 1, 2, 7};
        cout << arr_sum(a, 4, b, 5) << endl;
    }
    {
        double a[] = {3.0, 2, 0, val * 1.0};
        double b[] = {5, 6.1, 1, 2.3, 7};
        cout << arr_sum(a, 4, b, 5) << endl;
    }

    return 0;
}
