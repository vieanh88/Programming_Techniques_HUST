#include <vector>
#include <algorithm>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <cstdio>
//Do Thi Thanh Binh 20215315 
using namespace std;

const int LIMIT = 100;
const int NUM_ITER = 100000;
const int NUM_INPUTS = NUM_ITER * 100;

double sigmoid_slow(double x) {
    return 1.0 / (1.0 + exp(-x));
}

double x[NUM_INPUTS];

void prepare_input() {
    const int PRECISION = 1000000;
    const double RANGE = LIMIT / 20.0;
    for (int i = 0; i < NUM_INPUTS; ++i) {
        x[i] = RANGE * (rand() % PRECISION - rand() % PRECISION) / PRECISION;
    }
}

//# BEGIN fast code

//# khai b�o c�c bi?n ph? tr? c?n thi?t
const double start = -15.0;
const double stop = 15.0;
const long denta = 400000; //So luong buoc chia trong khoang start den stop
double a[denta + 5]; //Mang luu tru gia tri ham sigmoid cua cac gia tri tu start den stop cach nhau denta 
double dist = (stop - start) / denta; //Khoang cach cua moi diem trong day a[]
double k, ratioo;
//Ham xap xi gia tri cua ham mu voi gia tri e^x xap xi chuoi Maclaurin 
inline double exponent(double x){
	double result = 1.0; //Khoi dau result bang 1.0
	double eps = 5e-7;  //Nguong xac dinh 
	double extra = x; //Luu tru gia gri ban dau cua x
	double n = 1; //Dem so lan cong them cac thanh phan vao chuoi 
	while (fabs(extra) > eps){ //Khi gia tri tuyet doi cua extra nho hon nguong xac dinh eps
		result += extra; //Xay dung cac thanh phan cua chuoi Taylor
		n ++; //Tang n
		extra = (extra*x) / n; //Thanh phan moi cua chuoi Taylor 
	} 
	return result; 
} 

//# h�m chuan bi du lieu truoc, tinh toan gia tri ham sigmoid tai moi diem trong khoang tu start den stop  
void precalc() {
	a[0] = start;
	
	for(long i = 1; i <= denta; i++){
		a[i] = a[i-1] + dist; 
	} 
	for(long i = 0; i <= denta; i++){
		a[i] = 1 / (1 + exponent(-a[i]));
	} 
}

//# h�m t�nh sigmoid(x) nhanh sigmoid_fast(x)  
inline double sigmoid_fast(double x) {
	if(x > stop) return 1.0;
	else if(x < start) return 0.0;
	else { //Neu x nam trong khoang tu start den stop 
		k = floor((x - start) / dist); //Bien k luu tru vi tri cua khoang x nam trong day da chuan bi truoc 
		ratioo = (x - start) / dist - k; //Bien tinh toan ti le cua x nam trong khoang giua k va k+1 
		long p = (long)k; //a[p] va a[p+1] l� gia tri sigmoid gan nhat trong day da chuan bi  
		return a[p] + (a[p+1] - a[p]) * ratioo;  //Ting sigmoid(x) dua tren ti le ratioo giua a[p] va a[p+1] 
	} 
}

//# END fast code

double benchmark(double (*calc)(double), vector<double> &result) {
    const int NUM_TEST = 20;

    double taken = 0;
    result = vector<double>();
    result.reserve(NUM_ITER);

    int input_id = 0;
    clock_t start = clock();
    for (int t = 0; t < NUM_TEST; ++t) {
        double sum = 0;
        for (int i = 0; i < NUM_ITER; ++i) {
            double v = fabs(calc(x[input_id]));
            sum += v;
            if (t == 0) result.push_back(v);
            if ((++input_id) == NUM_INPUTS) input_id = 0;
        }
    }
    clock_t finish = clock();
    taken = (double)(finish - start);
//#  printf("Time: %.9f\n", taken / CLOCKS_PER_SEC);
    return taken;
}

bool is_correct(const vector<double> &a, const vector<double> &b) {
    const double EPS = 1e-6;

    if (a.size() != b.size()) return false;
    for (unsigned int i = 0; i < a.size(); ++i) {
        if (fabs(a[i] - b[i]) > EPS) {
            return false;
        }
    }
    return true;
}

int main() {
    prepare_input();
    precalc();

    vector<double> a, b;
    double slow = benchmark(sigmoid_slow, a);
    double fast = benchmark(sigmoid_fast, b);

    double xval;
    scanf("%lf", &xval);
    printf("%.2f \n", sigmoid_fast(xval));
    
    if (is_correct(a, b) && (slow/fast > 1.3)) {
        printf("Correct answer! Your code is faster at least 30%%!\n");
    } else {
        printf("Wrong answer or your code is not fast enough!\n");
    }
    
    return 0;
}
