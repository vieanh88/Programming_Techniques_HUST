#include <iostream>
#include <vector>
#include <cmath>
#include <complex>
//Do thi Thanh Binh 20215315 
using namespace std;

const double PI = acos(-1); //Ding nghia hang so PI = arccos(-1)
//Ham fast_fourier bien doi Fourier nhanh (FFT) voi dau vao la mot vector cac so phuc va tham so boolean   
void fast_fourier(vector< complex<double> > &p, bool invert) {
	int n = p.size();
	if(n==1) return; //Neu kich thuoc dau vao la 1 th� khong can thuc hien FFT  
	vector< complex<double> > p_0(n/2), p_1(n/2);
	//Phan chia p thanh hai vector p_0 v� p_1  
	for( int i=0; 2*i<n; i++){
		p_0[i] = p[2*i];
		p_1[i] = p[2*i+1]; 
	} 
	//De quy FFT tren cac vector con p_0 v� p_1 
	fast_fourier(p_0, invert);
	fast_fourier(p_1, invert);
	//Tinh goc va so phuc can thiet cho viec tinh toan FFT 
	double angle = 2*PI/n * (invert ? -1 : 1);
	complex<double> matrix_element(1), matrix_element_n(cos(angle), sin(angle));
	//Bien doi trong thuat toan FFT 
	for(int i=0; 2*i<n; i++){
		p[i] = p_0[i] + matrix_element * p_1[i];
		p[i + n/2] = p_0[i] - matrix_element * p_1[i];
		if(invert){
			p[i] /= 2;
			p[i + n/2] /= 2; 
		} 
		matrix_element = matrix_element * matrix_element_n; 
	} 
}
// polynomial_multiply de nhan hai da thuc bieu dien duoi dang hai vector a va b  
vector<int> polynomial_multiply(vector<int> &a, vector<int> &b){
	//Chuan bi cac da thuc dau vao de nhan chung bang FFT 
	vector< complex<double> > fa(a.begin(), a.end()), fb(b.begin(), b.end());
	int n = 1;
	while (n < a.size() + b.size()) n <<= 1;
	fa.resize(n);
	fb.resize(n);
	fast_fourier(fa, false);
	fast_fourier(fb, false);
	//Thuc hien phep nhan cac da thuc duoc bien doi tu FFT  
	for(int i=0; i<n; i++) 
		fa[i] *= fb[i];
	fast_fourier(fa, true);
	//da thuc ket qua duoi dang mot vector cac so nguyen 
	vector<int> result(n); 
	for(int i=0; i<n; i++)
		result[i] = round(fa[i].real()); //Gan bang ket qua phep nhan  
	return result; 
} 

int main(){
	int N, M;
	vector<int> a, b; 
	//Nhap da thuc a 
	cin >> N;
	for(int i=0; i<=N; i++){
		int x;
		cin >> x;
		a.push_back(x); 
	} 
	//Nhap da thuc b 
	cin >> M;
	for(int i=0; i<=M; i++){
		int x;
		cin >> x;
		b.push_back(x); 
	}
	//Thuc hien nhan a voi b va luu vao c 
	vector<int> c = polynomial_multiply(a,b);
	int h = N + M + 1;
	//Thuc hien phep XOR cac he so cua da thuc c  
	int xor_c = c[0] ^ c[1];
	for(int i=2; i<h; i++)
		xor_c = xor_c ^ c[i];
	cout << endl << xor_c; //In ra ket qua  
	return 0; 
} 


