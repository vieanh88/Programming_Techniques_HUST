#include <iostream>
#include <ostream>
#include <math.h>
#include <iomanip> 
//Do Thi Thanh Binh 20215315
using namespace std;

struct Complex {
    double real;
    double imag;
};
/*  a = x + y.i 
	b = x' + y'.i
	*/
	
// a + b = (x+x') + (y+y').i 
Complex operator + (Complex a, Complex b) {
    Complex tmp;
    tmp.real = a.real + b.real;
	tmp.imag = a.imag + b.imag;
	return tmp; 
}
// a - b = (x-x') + (y-y').i 
Complex operator - (Complex a, Complex b) {
    Complex tmp;
    tmp.real = a.real - b.real;
	tmp.imag = a.imag - b.imag;
	return tmp; 
}
// a * b = ( x.x' - y.y') + (x.y' + x'.y).i 
Complex operator * (Complex a, Complex b) {
    Complex tmp;
    tmp.real = a.real*b.real - a.imag*b.imag;
	tmp.imag = a.imag*b.real + a.real*b.imag;
	return tmp; 
}
// a/b = (x.x' + y.y')/(x'^2 + y'^2) + (y.x' - x.y').i/(x'^2 + y'^2)
Complex operator / (Complex a, Complex b) {
    Complex tmp;
    tmp.real = (a.real*b.real + a.imag*b.imag)/(b.imag*b.imag+b.real*b.real);
	tmp.imag = (a.imag*b.real-a.real*b.imag)/(b.imag*b.imag+b.real*b.real);
	return tmp;  
}

ostream& operator << (ostream& out, const Complex &a) {
    out << '(' << std::setprecision(2) << a.real << (a.imag >= 0 ? '+' : '-') << std::setprecision(2) << fabs(a.imag) << 'i' << ')';
    return out;
}

int main() {
    double real_a, real_b, img_a, img_b;
    cin >> real_a >> img_a;
    cin >> real_b >> img_b;
    
    Complex a{real_a, img_a};
    Complex b{real_b, img_b};
    
    cout << a << " + " << b << " = " << a + b << endl;
    cout << a << " - " << b << " = " << a - b << endl;
    cout << a << " * " << b << " = " << a * b << endl;
    cout << a << " / " << b << " = " << a / b << endl;
    
    return 0;
}
