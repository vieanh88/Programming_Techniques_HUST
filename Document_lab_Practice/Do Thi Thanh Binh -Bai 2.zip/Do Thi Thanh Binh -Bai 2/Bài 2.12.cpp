#include<iostream>
#include<vector>
#include<algorithm>
//Do Thi Thanh Binh 20215315

using namespace std;
//Cau truc T gom cap khoa va gia tri  
struct T{
	int key;
	int value; 
}; 

vector<T> list; //Vector list luu tru c�c phan tu co kieu du lieu la T 
int main(){
	int k, v; 
	while(cin >> k >> v){ //Doc gia tri vao k va v cho den khi khong hop le hoac gap so am  
		if(k <0 || v < 0) break; //Neu k hoac v am thi thoat khoi vong lap  
		T tmp; //bien cau truc tam thoi kieu T 
		tmp.key = k; //Gan gia tri khoa va gia tri vao tmp  
		tmp.value = v;
		list.push_back(tmp); //Day vao vector list  
	} 
	sort(list.begin(), list.end(), [](T a, T b){ //Sap xep list dua tren ham so sanh tuy chinh  
		if(a.value > b.value ) return true; //Sap xep theo value giam dan  
		else if(a.value < b.value ) return false;
		else return a.key >= b.key; //Neu value bang nhau thi so sanh key  
	});
	for(unsigned int i=0; i < list.size(); i++){
		cout << list[i].key << " " << list[i].value << endl; //Xuat cac cap sau khi da dc sap xep  
	} 
	return 0; 
} 
