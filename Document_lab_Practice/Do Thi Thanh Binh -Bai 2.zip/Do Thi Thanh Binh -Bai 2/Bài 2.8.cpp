#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
//Do Thi Thanh Binh 20215315 
using namespace std;

int main() {
    int val1, val2;
    cin >> val1 >> val2;
    vector< vector<int> > a = {
        {1, 3, 7},
        {2, 3, 4, val1},
        {9, 8, 15},
        {10, val2},
    };
	//Sap xep cac phan tu trong vector a bang ham so sanh tuy chinh 
    sort(a.begin(), a.end(), [](vector<int> x, vector<int> y){ //Ham nac danh so sanh 2 thanh phan 
    	int sum1 = 0, sum2 = 0; //Tong cac phan tu cua 2 thanh phan 
		for( unsigned int i=0; i< x.size(); i++){
			sum1 += x[i]; //Tong cac phan tu cua vector x
		} 
		for( unsigned int i=0; i< y.size(); i++){
			sum2 += y[i];  //Tong cac phan tu cua vector y
		}
		return sum1 > sum2; //Sap xep theo tong cac phan tu giam dan 
	}); 
    
    for (const auto &v : a) {
        for (int it : v) {
            cout << it << ' ';
        }
        cout << endl;
    }
    return 0;
}
