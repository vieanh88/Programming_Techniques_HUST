#include <stdio.h>
#include <math.h>
//Do Thi Thanh Binh 20215315
//Ham tinh do dai canh huyen voi dau vao la do dai hai canh goc vuong  
float get_hypotenuse(float x, float y) {
    return sqrt(x*x+y*y); //hypotenuse = sqrt(x^2+y^2) 
}

int main(){
    float x, y;
    scanf("%f%f", &x, &y);
    
    float z = get_hypotenuse(x, y);
    printf("z = %.2f\n", z);
    
    return 0;
}
