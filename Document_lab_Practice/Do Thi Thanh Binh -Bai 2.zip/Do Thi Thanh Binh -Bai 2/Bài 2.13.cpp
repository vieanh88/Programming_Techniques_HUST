#include<iostream>
//Do Thi Thanh Binh 20215315
 
using namespace std;
//Dinh nghia cau truc bigNum de luu tru so lon 
struct bigNum{
	char sign;
	char num[101]; 
}; 
//Ham nhap vao hai so lon a va b 
void input(bigNum &a, bigNum &b){
	string tmp; //khai bao chuoi co ten tmp dung de luu so nhap vao tu ban phim  
	cin >> tmp; //Nhap chuoi tmp tu cin 
	a.sign = tmp[0]; //Dau cua so lon la phan tu dau tien cua chuoi tmp 
	int len1 = tmp.length() - 1; //Do dai chuoi luu thanh phan num cua bigNum 
	for(int i=0; i<len1; i++){
		a.num[100-len1 +i +1 ] = tmp[i+1]; //Gan so tu chuoi vao mang num cua bigNum 
	}
	for(int i=0; i<= 100-len1; i++){
		a.num[i] = '0'; //Dien '0' v�o cac vi tri trong con lai cua mang  
	}
	//Lam tuong tu de nhap vao so bigNum thu hai 
	cin >> tmp;
	b.sign = tmp[0];
	int len2 = tmp.length() - 1;
	for(int i=0; i<len2; i++){
		b.num[100-len2 +i +1 ] = tmp[i+1]; 
	}
	for(int i=0; i<= 100-len2; i++){
		b.num[i] = '0'; 
	} 
}
//Ham thuc hien phep cong giua hai so a, b va luu vao mang res 
void add(char res[], char *a, char *b){
	int c = 0; //bien nho khi cong  
	for(int i=100; i>=0; i--){
		int tmp = (int)a[i] - 48 + (int)b[i] - 48 + c;
		c = tmp/10;
		res[i] = tmp%10 + 48; 
	} 
} 
//Ham thuc hien phep tru giua a, b va luu vao mang res (voi a>=b) 
void sub(char res[], char *a, char *b){
	int c = 0; //Bien nho khi tru  
	for(int i=100; i>=0; i--){
		int tmp1 = (int)a[i] -48;
		int tmp2 = (int)b[i] -48;
		
		if(tmp1 >= tmp2 +c){  
			res[i]= tmp1 - tmp2 - c + 48;
			c=0; 
		} else {
			tmp1 = tmp1 + 10;
			res[i] = tmp1 - tmp2 - c + 48;
			c = 1; 
		} 
	} 
}
//Ham thuc hien phep nhan giua a, b va luu vao mang res
void multi(char res[], char *a, char *b){
	for(int i=0; i<= 100; i++){
		res[i] = '0'; //Khoi tao mang res bang '0'  
	} 
	for (int i=100; i >= 0; i--){
		 /*mang tam thoi tmp de luu tru ket qua sau tung vong lap nhan
		  tuong ung voi cac vi tri hang don vi, chuc, tram  */
		char tmp[101];
		int k; 
		for(k=0; k<i; k++){
			tmp[100-k] = '0';  
		}
		int c = 0, sum = 0; //c la bien nho  
		for(int j=100; j>=0; j--){ //nhan tung vi tri trong so a voi tung chu so trong so b 
			sum = ((int)a[i] - 48)*((int)b[j] - 48) + c;
			tmp[k] = sum%10 + 48;
			c = sum/10;
			k--;
			if(k<0) break; 
		} 
		add(res,tmp,res); //cong ket qua moi tinh duoc vao ket qua tong the res 
	} 
}
//Kiem tra xem a>=b ? 
bool check(char *a, char *b){
	int foo1, foo2;
	//Tim vi tri xuat hien cua chu so khac khong dau tien trong 2 mang a va b 
	for(foo1=0; foo1<101; foo1++){
		if(a[foo1] != '0') break; 
	}
	for(foo2=0; foo2<101; foo2++){
		if(b[foo2] != '0') break; 
	} 
	//so sanh vi tri xuat hien dau tien cua chu so khac khong trong 2 so a va b 
	if(foo1 > foo2) return false; //Vi tri dau tien cua a lon hon b thi a<b  
	else if(foo1 < foo2) return true; //Vi tri dau tien cua a nho hon b th� a>b 
	else{
		//Neu hai vi tri bang nhau thi so sanh tung chu so tu vi tri nay den het mang  
		int foo = foo1;
		while(foo < 101){
			if(a[foo] < b[foo]) return false;
			else if(a[foo] > b[foo]) return true;
			else foo++; 
		} 
	} 
	return true; //Neu khong c� truong hop nao phu hop nhu tren th� a>=b 
} 
// Overloading phep cong cho bigNum  
bigNum operator + (bigNum a, bigNum b){
	bigNum res;
	if(a.sign == '1' && b.sign == '1'){ //a duong, b duong => res duong  
		res.sign = '1';
		add(res.num, a.num, b.num);
		return res; 
	}else if(a.sign == '1' && b.sign == '0'){ // a duong, b am  
		if(check(a.num, b.num)){ //a>=b => res duong v� res.num = a.num-b.num  
			res.sign = '1';
			sub(res.num, a.num, b.num);
			return res; 
		}else{ //a<b => res am v� res.num = b.num-a.num
			res.sign = '0';
			sub(res.num, b.num, a.num);
			return res; 
		} 
	}else if(a.sign == '0' && b.sign == '1'){ //a am b duong  
		if(check(a.num, b.num)){ //a>=b => res am v� res.num = a.num-b.num
			res.sign = '0';
			sub(res.num, a.num, b.num);
			return res; 
		}else {  //a<b => res duong v� res.num = b.num-a.num
			res.sign = '1';
			sub(res.num, b.num, a.num);
			return res; 
		} 
	} else { //a am, b am => res am  
		res.sign = '0';
		add(res.num, a.num, b.num);
		return res; 
	} 
}
// Overloading phep tru cho bigNum 
// a - b = a + (-b) => doi dau b va thuc hien phep cong  
bigNum operator - (bigNum a, bigNum b){
	bigNum res;
	if(a.sign == '1' && b.sign == '0'){
		b.sign = '1';
		res = a + b; 
		return res; 
	} else if(a.sign == '1' && b.sign == '1'){
			b.sign = '0';
			res = a + b;
			return res; 
	} else if(a.sign == '0' && b.sign == '0'){
			b.sign = '1';
			res = a + b;
			return res; 
	} else{
		b.sign = '1';
		res = a + b;
		return res; 
	} 
}
// Overloading phep nhan cho bigNum 
// a va b cung dau thi res duong va thuc hien phep nhan a.num va b.num 
// a va b trai dau thi res am va thuc hien nhan thanh phan num cua hai so  
bigNum operator * (bigNum a, bigNum b){
	bigNum res;
	if(a.sign == '1' && b.sign == '1'){
		res.sign = '1';
		multi(res.num, a.num, b.num);
		return res; 
	} else if(a.sign == '1' && b.sign == '0'){
		res.sign = '0';
		multi(res.num, a.num, b.num);
		return res; 
	} else if(a.sign == '0' && b.sign == '1'){
		res.sign = '0';
		multi(res.num, a.num, b.num);
		return res; 
	} else {
		res.sign = '1';
		multi(res.num, a.num, b.num);
		return res;
	} 
}
//Ham in ra bigNum 
 void printBigNum(bigNum x){
 	cout << x.sign; //In ra bien dau cua bigNum  
 	int i; 
	for(i=0; i<101; i++) {
		if(x.num[i] != '0') break; //Chay den vi tri dau tien khac '0'
	}
	for(int k=i; k<101; k++) {
		cout << x.num[k] ;  //In chu so tu vi tri khac '0' dau tien do 
	}
 } 
int main(){
	bigNum a, b;
	input(a,b);
	bigNum so3, so4; 
	//Dinh nghia so 3 va 4 trong kieu du lieu bigNum  
	so3.sign = '1';
	so4.sign = '1';
	for(int i=0; i<100; i++){
		so3.num[i] = '0';
		so4.num[i] = '0'; 
	} 
	so3.num[100] = 3 + 48;
	so4.num[100] = 4 + 48;
	//Tinh a*b -3*a +4*b 
	bigNum T = a*b - so3*a + so4*b;
	printBigNum(T); //In ket qua ra man hinh  
	return 0; 
} 
