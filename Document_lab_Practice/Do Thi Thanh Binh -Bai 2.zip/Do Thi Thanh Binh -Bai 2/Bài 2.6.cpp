#include <stdio.h>
//Do Thi Thanh Binh 20215315
void print(int n) {
    printf("n=%d\n", n);
}

int mul3plus1(int n) {
    return n * 3 + 1;
}

int div2(int n) {
    return n / 2;
}

// khai b�o c�c tham so cho c�c con tri h�m odd, even v� output
void simulate(int n, int (*odd)(int), int (*even)(int), void (*output)(int) )  {
    (*output)(n);
    if (n == 1) return;
    if (n % 2 == 0) { //Neu n chan thi tro ve ham xu ly so chan  
        n = (*even)(n);
    } else { //Neu x le thi tro ve ham xu ly so le  
        n = (*odd)(n);
    }
    simulate(n, odd, even, output); //De quy cac gia tri vua thay doi  
}

int main() {
    int (*odd)(int) = NULL;
    int (*even)(int) = NULL;
    
    odd = mul3plus1;
    even = div2;

    int n;
    scanf("%d", &n);
    simulate(n, odd, even, print);

    return 0;
}
